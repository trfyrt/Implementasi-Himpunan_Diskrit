from setuptools import setup, find_packages

setup(
    name='himpunan_team7',
    version='0.1.0',
    description='A Python package for performing set operations (Himpunan)',
    author='Aaron Jevon Benedict Kongdoh, Derick Norlan, Excel Marcello Parinussa',
    packages=find_packages(),
    install_requires=[],
)